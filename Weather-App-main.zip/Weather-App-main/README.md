# Weather-App
Welcome to the Weather App repository! This project is a simple and intuitive weather application built using HTML, CSS, and JavaScript. It fetches real-time weather data from the OpenWeatherMap API and displays it in a user-friendly interface.
